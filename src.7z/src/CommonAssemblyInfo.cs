// Generated: 16.05.2017 08:34:30 (UTC)
// Warning: This is generated code! Don't touch as it will be overridden by the build process.

using System.Reflection;

[assembly: AssemblyVersion("3.0.173.0")]
[assembly: AssemblyFileVersion("3.0.173.0")]
[assembly: AssemblyInformationalVersion("3.0.173")]