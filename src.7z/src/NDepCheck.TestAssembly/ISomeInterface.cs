﻿using NDepCheck.TestAssembly.dir1.dir3;

namespace NDepCheck.TestAssembly.dir1.dir2 {
    public interface ISomeInterface {
        int IntMethod();
        Class13A Class13AMethod(Class13B b, Class13C c);
        Class13E.Class13EInner.Class13EInnerInner CreateInner3();
    }
}