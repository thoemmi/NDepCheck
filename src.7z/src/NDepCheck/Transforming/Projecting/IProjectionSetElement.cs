namespace NDepCheck.Transforming.Projecting {
    public interface IProjectionSetElement {
        Projection[] AllProjections { get; }
    }
}