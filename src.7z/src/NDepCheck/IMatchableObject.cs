namespace NDepCheck {
    public interface IMatchableObject {
    }
}