﻿namespace NDepCheck {
    public interface ICalculator : IPlugin {
        string Calculate(string[] values);
    }
}
