﻿namespace NDepCheck {
    internal enum Ignore {
        Om
    }
}
