namespace NDepCheck {
    public interface IWithCt {
        int Ct { get; }
        int NotOkCt { get; }
    }
}