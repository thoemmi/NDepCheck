// Generated: 21.03.2017 06:56:31 (UTC)
// Warning: This is generated code! Don't touch as it will be overridden by the build process.

using System.Reflection;

[assembly: AssemblyVersion("3.0.38.0")]
[assembly: AssemblyFileVersion("3.0.38.0")]
[assembly: AssemblyInformationalVersion("3.0.38")]