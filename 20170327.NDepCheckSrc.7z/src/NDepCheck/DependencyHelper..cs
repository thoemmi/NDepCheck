// (c) HMM�ller 2006...2017

using System.Collections.Generic;
using System.Linq;

namespace NDepCheck {
    public static class DependencyHelper {

    }
}