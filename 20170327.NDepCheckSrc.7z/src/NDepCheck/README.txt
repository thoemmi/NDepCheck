DotNetArchitectureChecker - a Dependency Checker for .NET
=========================================================

For installation, please open the file docs/index.html and go to "Installation".

For usage and documentation, please read through docs/index.html.
