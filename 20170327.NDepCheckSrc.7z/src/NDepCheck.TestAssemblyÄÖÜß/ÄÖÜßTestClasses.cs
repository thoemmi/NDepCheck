// (c) HMM�ller 2006...2010

namespace NDepCheck.TestAssembly����.dir1.dir3 {
    public struct Test2 {
        public int I;
    }
}